import { IResult } from "./result";

export interface IRootObject {
    matching_results : number;
    results:IResult[];
}
